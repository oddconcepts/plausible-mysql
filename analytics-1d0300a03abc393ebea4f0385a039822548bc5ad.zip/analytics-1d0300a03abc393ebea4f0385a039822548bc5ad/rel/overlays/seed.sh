#!/bin/sh

BIN_DIR=`dirname "$0"`

${BIN_DIR}/bin/plausible eval Plausible.Release.seed