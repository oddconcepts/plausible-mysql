defmodule PlausibleWeb.UnsubscribeView do
  use PlausibleWeb, :view
end
