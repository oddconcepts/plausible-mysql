use Mix.Config

# For the actual-production deployments we will use releases,
# i.e., "releases.exs" is the _actual_ production config
# see "releases.exs"

import_config "releases.exs"
