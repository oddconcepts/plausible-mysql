# UAInspector Parser Databases

The files in this directory are taken from the
[matomo-org/device-detector](https://github.com/matomo-org/device-detector)
project. See there for detailed license information about the data contained.
